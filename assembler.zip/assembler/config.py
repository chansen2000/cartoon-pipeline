"""TVCartoon 组装系统 — 配置与常量"""

import os

# ── 素材路径 ──────────────────────────────────────────
CAT_DIR = "/Users/chansen2000/Downloads/素材/选择/小猫"
CHARACTERS_JSON = os.path.join(CAT_DIR, "Json Atlas/Characters.json")
SPINE_ROOT = os.path.join(CAT_DIR, "Spine")

OUTPUT_DIR = os.path.join(os.path.dirname(__file__), "..", "output")
PICTURE_DIR = os.path.join(OUTPUT_DIR, "picture")
JSON_DIR = os.path.join(OUTPUT_DIR, "json")

# 画布尺寸
CANVAS_W, CANVAS_H = 788, 504
P4_W, P4_H = 410, 502

# ── 部件分类 ──────────────────────────────────────────
CORE_PARTS = {"Shadow", "Body", "Eye1", "Eye2", "Leg_B", "Leg_F",
              "Tails", "Hand_B", "Hand_F"}
ACCESSORY_PARTS = {"Hat", "Glasses", "Cloth"}
PROP_PARTS = {"Hammer", "Umbrella", "Hand_B2", "Leg_F2"}
FX_PARTS = {"Confuse Fx1", "Confuse Fx2", "Confuse Fx3",
            "Confuse Fx4", "Confuse Fx5", "Confuse Fx6",
            "Star", "Splash", "Splash2", "Box"}

# ── 各角色配饰 ────────────────────────────────────────
CHAR_ACCESSORIES = {
    "C01": {"hat": True,  "glasses": True,  "cloth": False},
    "C02": {"hat": True,  "glasses": False, "cloth": False},
    "C03": {"hat": True,  "glasses": False, "cloth": True},
    "C04": {"hat": False, "glasses": False, "cloth": True},
    "C05": {"hat": False, "glasses": False, "cloth": False},
    "C06": {"hat": True,  "glasses": False, "cloth": False},
    "C07": {"hat": False, "glasses": False, "cloth": True},
    "C08": {"hat": False, "glasses": True,  "cloth": False},
    "C09": {"hat": False, "glasses": False, "cloth": False},
    "C10": {"hat": False, "glasses": False, "cloth": False},
    "C11": {"hat": False, "glasses": False, "cloth": False},
    "C12": {"hat": False, "glasses": False, "cloth": False},
    "C13": {"hat": False, "glasses": False, "cloth": False},
    "C14": {"hat": False, "glasses": True,  "cloth": False},
    "C15": {"hat": True,  "glasses": False, "cloth": False},
}

# ── 默认配置 ──────────────────────────────────────────
DEFAULT_ACCESSORIES = {"hat": True, "glasses": True, "cloth": True}
DEFAULT_PROPS = {"hammer": False, "umbrella": False}
DEFAULT_EFFECTS = {"confuse": False, "star": False, "splash": False}

# ── 点击动画映射 ──────────────────────────────────────
CLICK_ANIM_MAP = {
    "Body":   "bounce",
    "Eye1":   "spin",
    "Eye2":   "spin",
    "Tails":  "wag",
    "Hat":    "bounce",
    "Shadow": None,
    "Leg_B":  None,
    "Leg_F":  None,
    "Hand_B": None,
    "Hand_F": None,
}
